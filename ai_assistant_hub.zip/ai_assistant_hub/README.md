# Enhanced AI Assistant Hub - Ultimate Version

An advanced AI integration system for Godot Engine featuring dual AI provider support, automation capabilities, and comprehensive assistant management.

## 🚀 Key Features

### 🤖 Dual AI System
- **Text Generation**: Support for multiple LLM providers (OpenRouter, Gemini, Ollama, Z.AI GLM)
- **Visual Content**: Scenario AI integration for image generation
- **Provider Management**: Easy switching between different AI providers
- **API Key Management**: Secure storage and management of API keys and secrets

### 🎯 Enhanced Automation
- **AI Automation Manager**: Advanced task delegation and automation
- **Auto-Approval System**: Intelligent approval workflows for AI tasks
- **Smart Context Management**: Maintains conversation context across sessions
- **Quick Prompts**: Predefined prompts for common development tasks

### 💬 Advanced Chat Interface
- **Multi-Tab Conversations**: Support for multiple simultaneous AI conversations
- **Bot Portraits**: Animated AI assistant portraits with thinking states
- **Chat History**: Persistent conversation storage and management
- **Code Formatting**: Automatic syntax highlighting for code responses
- **Auto-Scroll Control**: Configurable scrolling behavior for AI responses

### ⚙️ Configuration & Management
- **Assistant Types**: Create and manage different AI assistant personalities
- **Model Selection**: Choose from available models for each provider
- **Temperature Control**: Adjust AI creativity and response variability
- **Project Integration**: Seamless integration with Godot's editor interface

## 📋 Supported AI Providers

### Text Generation (LLM)
- **OpenRouter**: Access to multiple models (GPT-4, Claude, Llama, etc.)
- **Google Gemini**: Direct integration with Google's AI models
- **Ollama**: Local model hosting for privacy and offline usage
- **Z.AI GLM**: Chinese language model support

### Visual Content Generation
- **Scenario AI**: Professional image generation with API key and secret key support

## 🛠️ Installation

1. **Download**: Get the latest version from the [Releases](https://github.com/FlamxGames/godot-ai-assistant-hub/releases) page
2. **Install**: Copy the `ai_assistant_hub` folder to your project's `addons/` directory
3. **Enable**: Go to `Project > Project Settings > Plugins` and enable "AI Assistant Hub"
4. **Configure**: Set up your API keys in the AI Hub panel (appears at the bottom of the editor)

## 🔧 Configuration

### Setting Up API Keys

1. **Open AI Hub**: The AI Hub panel appears at the bottom of the Godot editor
2. **Select Provider**: Choose your preferred AI provider from the dropdown
3. **Configure API**:
   - For most providers: Enter your API key in the "Server URL / API key" field
   - For Scenario AI: Enter both API key and secret key in the dedicated fields
4. **Test Connection**: Click "Refresh Models" to verify your configuration

### Creating AI Assistants

1. **Select Model**: Choose a model from the available options
2. **Click "New Assistant Type"**: Configure assistant properties:
   - **Name**: Display name for the assistant
   - **Description**: System prompt that defines the assistant's behavior
   - **Temperature**: Creativity level (0.0 = focused, 1.0 = creative)
   - **Quick Prompts**: Predefined actions for common tasks
3. **Save**: The assistant will be available for new conversations

## 🎮 Usage

### Starting a Conversation

1. **Select Assistant**: Click on an assistant type in the AI Hub
2. **New Chat**: A new tab will open with the selected assistant
3. **Start Chatting**: Type your message and press Enter (Shift+Enter for new line)

### Quick Prompts

Quick prompts allow you to perform common development tasks quickly:

- **Code Analysis**: `{CODE}` placeholder inserts selected code from the editor
- **Chat Context**: `{CHAT}` placeholder includes current chat content
- **Custom Actions**: Create your own quick prompts in assistant configuration

### Automation Features

The enhanced version includes advanced automation capabilities:

- **Task Delegation**: Automatically delegate complex tasks to specialized AI systems
- **Auto-Approval**: Intelligent approval system for AI-generated content
- **Context Preservation**: Maintain context across different AI providers
- **Workflow Integration**: Seamlessly integrate with your development workflow

## 🔍 Advanced Features

### Chat History Management

- **Persistent Storage**: Conversations are automatically saved when the save checkbox is enabled
- **History Editor**: Edit and manage conversation history
- **Export/Import**: Save and load conversation archives

### Code Integration

- **Editor Selection**: Automatically includes selected code from the script editor
- **Syntax Highlighting**: Proper formatting for code blocks in responses
- **Multiple Languages**: Support for various programming languages

### Customization Options

- **Interface Preferences**: Configure auto-scroll behavior and greeting settings
- **Thinking Process Control**: Choose how to handle AI thinking tags
- **Temperature Override**: Fine-tune AI responses per conversation

## 🐛 Troubleshooting

### Common Issues

1. **LLM Provider Dropdown Empty**
   - Ensure provider files are in `addons/ai_assistant_hub/llm_providers/`
   - Check that `.tres` files are properly formatted
   - Restart Godot after adding new providers

2. **API Connection Errors**
   - Verify API keys are correct and active
   - Check internet connection
   - Ensure provider URLs are correct
   - Review provider-specific documentation

3. **Plugin Loading Errors**
   - Check for conflicting class names in other addons
   - Ensure all required files are present
   - Review Godot output console for specific error messages

4. **Scenario AI Issues**
   - Ensure both API key and secret key are provided
   - Verify keys are active and have proper permissions
   - Check Scenario AI service status

### Debug Information

Enable debug output by checking the Godot console for detailed information about:
- Provider loading process
- API connection status
- Model availability
- Error details

## 📚 Developer Information

### File Structure

```
addons/ai_assistant_hub/
├── ai_assistant_hub.gd          # Main hub interface
├── ai_assistant_hub.tscn        # Scene file for UI
├── ai_hub_plugin.gd             # Plugin entry point
├── llm_interface.gd             # Base interface for LLM providers
├── llm_provider_resource.gd     # Resource for provider configuration
├── llm_providers/               # Provider configuration files
├── llm_apis/                    # LLM API implementations
├── assistants/                  # Assistant type configurations
├── graphics/                    # UI assets and portraits
└── [additional files...]        # Supporting scripts and resources
```

### Adding New LLM Providers

1. **Create Provider Resource**: Add `.tres` file in `llm_providers/`
2. **Implement API**: Create `.gd` file in `llm_apis/` extending `LLMInterface`
3. **Register**: Add provider to the dropdown system

### Custom Automation

The enhanced version supports custom automation systems:

- **AIAutomationManager**: Core automation controller
- **AutoApprovalSystem**: Approval workflow management
- **Custom Tasks**: Extend with your own automation logic

## 🤝 Contributing

1. **Fork**: Create a fork of the repository
2. **Develop**: Make your changes in a feature branch
3. **Test**: Ensure all functionality works correctly
4. **Submit**: Create a pull request with detailed description

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🔗 Links

- **Main Repository**: [GitHub](https://github.com/FlamxGames/godot-ai-assistant-hub)
- **Issues & Support**: [GitHub Issues](https://github.com/FlamxGames/godot-ai-assistant-hub/issues)
- **Documentation**: [Wiki](https://github.com/FlamxGames/godot-ai-assistant-hub/wiki)
- **Discord Community**: [Join our Discord](https://discord.gg/)

## 🆕 Version History

### Ultimate Enhanced Version
- ✅ Dual AI provider support (LLM + Visual)
- ✅ Advanced automation capabilities
- ✅ Enhanced UI with Scenario AI integration
- ✅ Improved error handling and debugging
- ✅ Performance optimizations
- ✅ Comprehensive configuration options

### Previous Versions
- See [CHANGELOG.md](CHANGELOG.md) for detailed version history

## 📞 Support

For support and questions:

- **Documentation**: Check the [Wiki](https://github.com/FlamxGames/godot-ai-assistant-hub/wiki) for detailed guides
- **Issues**: Report bugs on [GitHub Issues](https://github.com/FlamxGames/godot-ai-assistant-hub/issues)
- **Community**: Join discussions on [Discord](https://discord.gg/)
- **Email**: Contact development team for enterprise support

---

**Made with ❤️ for the Godot community**
